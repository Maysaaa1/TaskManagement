﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using TaskManagementSystem.Application.Interfaces;
using TaskManagementSystem.Application.ViewModels;
using TaskManagementSystem.Application.Dtos.AppTask;
using AutoMapper;

namespace TaskManagementSystem.Web.Controllers
{
    [Authorize]
    public class AppTaskController : Controller
    {
        private readonly IAppTaskManager _manager;
        private readonly ICategoryManager _categoryManager;
        private readonly IPriorityManager _priorityManager;
        private readonly UserManager<IdentityUser> _userManager;
        private readonly IMapper _mapper;

        public AppTaskController(
            IAppTaskManager manager,
            ICategoryManager categoryManager,
            IPriorityManager priorityManager,
            UserManager<IdentityUser> userManager,
            IMapper mapper)
        {
            _manager = manager;
            _categoryManager = categoryManager;
            _priorityManager = priorityManager;
            _userManager = userManager;
            _mapper = mapper;
        }

        public async Task<IActionResult> Index()
        {
            if (User.IsInRole("Admin"))
            {
                var allTasks = await _manager.GetAllTasksAsync();
                return View(allTasks);
            }

            var email = User.Identity?.Name!;
            var tasks = await _manager.GetTasksByAssignedToEmailAsync(email);
            return View(tasks);
        }

        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> Create()
        {
            var vm = await BuildFormViewModelAsync();
            return View(vm);
        }

        [HttpPost]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> Create(AppTaskFormViewModel model)
        {
            if (!ModelState.IsValid)
            {
                model = await BuildFormViewModelAsync(model);
                return View(model);
            }

            var createDto = _mapper.Map<AppTaskCreateDto>(model.Task);
            await _manager.CreateTaskAsync(createDto);
            return RedirectToAction(nameof(Index));
        }

        [HttpPost]
        public async Task<IActionResult> MarkCompleted(int id)
        {
            await _manager.MarkTaskAsCompletedAsync(id);
            return RedirectToAction(nameof(Index));
        }

        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> Edit(int id)
        {
            var taskEntity = await _manager.GetEntityByIdAsync(id);
            if (taskEntity == null)
                return NotFound();

            var updateDto = _mapper.Map<AppTaskUpdateDto>(taskEntity);
            var formDto = _mapper.Map<AppTaskDto>(updateDto);

            var vm = await BuildFormViewModelAsync(new AppTaskFormViewModel
            {
                Task = formDto
            });

            return View(vm);
        }

        [HttpPost]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> Edit(AppTaskFormViewModel model)
        {
            if (!ModelState.IsValid)
            {
                model = await BuildFormViewModelAsync(model);
                return View(model);
            }

            var updateDto = _mapper.Map<AppTaskUpdateDto>(model.Task);
            await _manager.UpdateTaskAsync(model.Task.Id,updateDto);
            return RedirectToAction(nameof(Index));
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> Delete(int id)
        {
            await _manager.DeleteTaskAsync(id);
            return RedirectToAction(nameof(Index));
        }

       

        private async Task<AppTaskFormViewModel> BuildFormViewModelAsync(AppTaskFormViewModel? model = null)
        {
            model ??= new AppTaskFormViewModel();

            model.Categories = (await _categoryManager.GetAllAsync())
                .Select(c => new SelectListItem { Value = c.Id.ToString(), Text = c.Name }).ToList();

            model.Priorities = (await _priorityManager.GetAllPrioritiesAsync())
                .Select(p => new SelectListItem { Value = p.Id.ToString(), Text = p.Name }).ToList();

            model.Users = _userManager.Users
                .Select(u => new SelectListItem { Value = u.Email, Text = u.Email }).ToList();

            return model;
        }
    }
}
