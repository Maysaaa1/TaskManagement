﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using TaskManagementSystem.Application.Dtos.Priority;
using TaskManagementSystem.Application.Interfaces;
using AutoMapper;

namespace TaskManagementSystem.Web.Controllers
{
    [Authorize(Roles = "Admin")]
    public class PriorityController : Controller
    {
        private readonly IPriorityManager _priorityManager;
        private readonly IMapper _mapper;

        public PriorityController(IPriorityManager priorityManager, IMapper mapper)
        {
            _priorityManager = priorityManager;
            _mapper = mapper;
        }

        public async Task<IActionResult> Index()
        {
            var priorities = await _priorityManager.GetAllPrioritiesAsync();
            return View(priorities);
        }

        public IActionResult Create()
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> Create(PriorityCreateDto dto)
        {
            if (!ModelState.IsValid)
                return View(dto);

            await _priorityManager.CreateAsync(dto);
            return RedirectToAction(nameof(Index));
        }

        public async Task<IActionResult> Delete(int id)
        {
            var priority = await _priorityManager.GetPriorityByIdAsync(id);
            if (priority == null)
                return NotFound();

            return View(priority);
        }

        [HttpPost, ActionName("Delete")]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            await _priorityManager.DeleteAsync(id);
            return RedirectToAction(nameof(Index));
        }

        
        [HttpGet]
        public async Task<IActionResult> EditPartial(int id)
        {
            var priority = await _priorityManager.GetEntityByIdAsync(id);
            if (priority == null) return NotFound();

            var dto = _mapper.Map<PriorityUpdateDto>(priority);
            return PartialView("_EditPartial", dto);
        }

        
        [HttpPost]
        public async Task<IActionResult> Edit(PriorityUpdateDto dto)
        {
            if (!ModelState.IsValid)
                return BadRequest(ModelState); 

            await _priorityManager.UpdateAsync(dto.Id, dto);
            return RedirectToAction(nameof(Index));
        }
    }
}
