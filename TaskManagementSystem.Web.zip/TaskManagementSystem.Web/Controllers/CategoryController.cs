﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using TaskManagementSystem.Application.Dtos.Category;
using TaskManagementSystem.Application.Interfaces;
using AutoMapper;

namespace TaskManagementSystem.Web.Controllers;

[Authorize(Roles = "Admin")]
public class CategoryController : Controller
{
    private readonly ICategoryManager _categoryManager;
    private readonly IMapper _mapper;

    public CategoryController(ICategoryManager categoryManager, IMapper mapper)
    {
        _categoryManager = categoryManager;
        _mapper = mapper;
    }

    public async Task<IActionResult> Index()
    {
        var categories = await _categoryManager.GetAllAsync();
        return View(categories);
    }

    public IActionResult Create()
    {
        return View();
    }

    [HttpPost]
    public async Task<IActionResult> Create(CategoryCreateDto dto)
    {
        if (!ModelState.IsValid)
            return View(dto);

        await _categoryManager.CreateAsync(dto);
        return RedirectToAction(nameof(Index));
    }
  
    public async Task<IActionResult> Delete(int id)
    {
        var category = await _categoryManager.GetByIdAsync(id);
        if (category == null)
            return NotFound();

        return View(category);
    }

    [HttpPost, ActionName("Delete")]
    public async Task<IActionResult> DeleteConfirmed(int id)
    {
        await _categoryManager.DeleteAsync(id);
        return RedirectToAction(nameof(Index));
    }
    [HttpGet]
    [HttpGet]
    [HttpGet]
    public async Task<IActionResult> EditPartial(int id)
    {
        var entity = await _categoryManager.GetEntityByIdAsync(id);
        var dto = _mapper.Map<CategoryUpdateDto>(entity);
        return PartialView("_EditPartial", dto);
    }



    [HttpPost]
    public async Task<IActionResult> Edit(CategoryUpdateDto dto)
    {
        if (!ModelState.IsValid)
            return PartialView("_EditPartial", dto); 

        await _categoryManager.UpdateAsync(dto.Id, dto); 
        return RedirectToAction(nameof(Index));
    }

}
